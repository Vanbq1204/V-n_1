import React, { useState, useEffect } from 'react';
import {
    Text, 
    View,
    Image,
    TouchableOpacity,
    TextInput,
    FlatList,
    ScrollView,
    Switch,
} from 'react-native'
import { images, colors, icons, fontSizes } from '../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome5';
import { UIHeader } from '../components';

function Settings(props){
    const[isEnabledLockApp,setEnabledLockApp] = useState(true)
    const[isEnabledChangePassword,setEnabledChangePassword] = useState(true)
    const[isUseFingerprint,setUseFingerprint] = useState(false)

    return<View style ={{
        flex : 1,
        backgroundColor :'white'
    }}>
        <UIHeader title = {"Settings"} />
        <ScrollView>
            <View style = {{
                height : 36,
                backgroundColor : 'rgba(0,0,0,0.2)',
                justifyContent : "center"
            }}>
                <Text style = {{
                    color : 'blue',
                    fontSize : fontSizes.h6,
                    paddingStart : 10,
                }} >Common</Text>
            </View>
            <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
            <Icon
                style = {{marginStart : 10}}    
                name = 'globe' size ={20} 
                color = 'black'
            />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Language</Text>
                <View style = {{flex :1}} ></View>
                <Text style = {{
                    color : 'black',
                    fontSize : fontSizes.h6,
                    paddingEnd : 10,
                    opacity : 0.5

                }}>English</Text>
                <Icon
                    style = {{
                        paddingEnd : 10,
                        opacity : 0.5

                    }}    
                    name = 'chevron-right'
                    size ={20} color = {'black'}
                />
                </View>
                <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
            <Icon
                style = {{marginStart : 10}}    
                name = 'cloud' size ={17} 
                color = 'black'
            />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Enviroment</Text>
                <View style = {{flex :1}} ></View>
                <Text style = {{
                    color : 'black',
                    fontSize : fontSizes.h6,
                    paddingEnd : 10,
                    opacity : 0.5
                }}>Production</Text>
                <Icon
                    style = {{
                        paddingEnd : 10,
                        opacity : 0.5
                    }}    
                    name = 'chevron-right'
                    size ={20} color = {'black'}
                />
                </View>
                <View style = {{
                height : 36,
                backgroundColor : 'rgba(0,0,0,0.2)',
                justifyContent : "center"
            }}>
                <Text style = {{
                    color : 'blue',
                    fontSize : fontSizes.h6,
                    paddingStart : 10,
                }} >Account</Text>
            </View>
            <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
            <Icon
                style = {{marginStart : 10}}    
                name = 'phone' size ={17} 
                color = 'black'
            />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Phone number</Text>
                <View style = {{flex :1}} ></View>
                <Icon
                    style = {{
                        paddingEnd : 10,
                        opacity : 0.5
                    }}    
                    name = 'chevron-right'
                    size ={20} color = {'black'}
                />
                </View>
                <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
            <Icon
                style = {{marginStart : 10}}    
                name = 'envelope' size ={17} 
                color = 'black'
            />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Email</Text>
                <View style = {{flex :1}} ></View>
                <Icon
                    style = {{
                        paddingEnd : 10,
                        opacity : 0.5
                    }}    
                    name = 'chevron-right'
                    size ={20} color = {'black'}
                />
                </View>
                <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
                <Icon
                style = {{marginStart : 10}}    
                name = 'sign-out-alt' size ={17} 
                color = 'black'
                />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Sign out</Text>
                <View style = {{flex :1}} ></View>
                <Icon
                    style = {{
                        paddingEnd : 10,
                        opacity : 0.5
                    }}    
                    name = 'chevron-right'
                    size ={20} color = {'black'}
                />
                </View>
            <View style = {{
                height : 36,
                backgroundColor : 'rgba(0,0,0,0.2)',
                justifyContent : "center"
            }}>
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'blue',
                    paddingStart : 10,
                }} >Security</Text>
            </View>
            <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
                <Icon
                style = {{marginStart : 10}}    
                name = 'door-closed' size ={17} 
                color = 'black'
                />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Lock app in background</Text>
                <View style = {{flex :1}} ></View>
                <Switch
                        trackColor={{false: colors.inactive, true: colors.primary}}
                        thumbColor={isEnabledLockApp ? colors.primary : colors.inactive}
                        //ios_backgroundColor="#3e3e3e"
                        onValueChange={()=>{
                            setEnabledLockApp(!isEnabledLockApp)
                        }}
                        value={isEnabledLockApp}
                        style = {{marginEnd : 10}}
                    />
                </View>
                <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
                <Icon
                style = {{marginStart : 10}}    
                name = 'fingerprint' size ={17} 
                color = 'black'
                />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Use fingerprint</Text>
                <View style = {{flex :1}} ></View>
                <Switch
                        trackColor={{false: colors.inactive, true: colors.primary}}
                        thumbColor={isUseFingerprint ? colors.primary : colors.inactive}
                        //ios_backgroundColor="#3e3e3e"
                        onValueChange={()=>{
                            setUseFingerprint(!isUseFingerprint)
                        }}
                        value={isUseFingerprint}
                        style = {{marginEnd : 10}}
                    />
                </View>
                <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
                <Icon
                style = {{marginStart : 10}}    
                name = 'lock' size ={17} 
                color = 'black'
                />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Change password</Text>
                <View style = {{flex :1}} ></View>
                <Switch
                        trackColor={{false: colors.inactive, true: colors.primary}}
                        thumbColor={isUseFingerprint ? colors.primary : colors.inactive}
                        //ios_backgroundColor="#3e3e3e"
                        onValueChange={()=>{
                            setEnabledChangePassword(!isEnabledChangePassword)
                        }}
                        value={isEnabledChangePassword}
                        style = {{marginEnd : 10}}
                    />
                </View>
                <View style = {{
                height : 36,
                backgroundColor : 'rgba(0,0,0,0.2)',
                justifyContent : "center"
                 }}>
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'blue',
                    paddingStart : 10,
                }} >Misc</Text>
                 </View>
                 <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
            <Icon
                style = {{marginStart : 10}}    
                name = 'passport' size ={20} 
                color = 'black'
            />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Term of service</Text>
                <View style = {{flex :1}} ></View>
                <Icon
                    style = {{
                        paddingEnd : 10,
                        opacity : 0.5

                    }}    
                    name = 'chevron-right'
                    size ={20} color = {'black'}
                />
                </View>
                <View style = {{
                    flexDirection : 'row',
                    paddingVertical : 10, // padding cho tất cả
                    alignItems :'center'
                }} >
            <Icon
                style = {{marginStart : 10}}    
                name = 'file-alt' size ={20} 
                color = 'black'
            />
                <Text style = {{
                    fontSize : fontSizes.h6,
                    color : 'black',
                    paddingStart : 10
                }}>Open source licenses</Text>
                <View style = {{flex :1}} ></View>
                <Icon
                    style = {{
                        paddingEnd : 10,
                        opacity : 0.5

                    }}    
                    name = 'chevron-right'
                    size ={20} color = {'black'}
                />
                </View>
                
                
        </ScrollView>
    </View>
}
export default Settings