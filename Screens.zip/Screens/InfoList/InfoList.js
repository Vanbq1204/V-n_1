import React, { useState, useEffect } from 'react';
import {
    Text, 
    View,
    Image,
    TouchableOpacity,
    TextInput,
    FlatList
} from 'react-native'
import { images, colors, icons, fontSizes } from '../../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
import { isValidEmail, isValidPassword } from '../utilies/Validations';
import Infoitem from './Infoitem';
/** 2 ways :
 - ListView from a map off object
 - FlatList
 */
function InfoList (props){
    // List of foods = state
    const [infos, setInfos] = useState([
        {
            name : 'Khoa công nghệ thông tin',
            url: 'https://fit.neu.edu.vn/img/logoFIT.png',
            status : "Opening now",
            price : 5223.56,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    facebook : 'https://www.facebook.com/',
                    instagram : 'https://www.instagram.com/',
                }
        
        },
        {
            name : 'Khoa toán kinh tế',
            url : 'https://mfe.edu.vn/wp-content/uploads/2019/04/LOGO_2_1000x1000_3_noBackground-copy-405x400.jpg',
            status : "Opening soon",
            price : 1968 ,
            website :'https://mfe.neu.edu.vn/',
            socialNetworks : 
                {
                    youtube : 'https://www.youtube.com/',
                    instagram : 'https://www.instagram.com/',
                }
            
        },
        {
            name : 'Viện đào tạo quốc tế ',
            url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPeFhGmpboXqHJTCyp-V_lnkqoRvy9ZCM1LA&s',
            status : "Closing soon",
            price : 5223.56,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    facebook : 'https://www.facebook.com/',
                    youtube : 'https://www.youtube.com/',
                }
        },
        {
            name : 'Khoa đầu tư',
            url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjXRD88IVf53hOtz_Hf-pq4II-mX7sUmetWQ&s',
            status : "Coming soon",
            price : 5223.56,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    facebook : 'https://www.facebook.com/',
                    youtube : 'https://www.youtube.com/',
                    instagram : 'https://www.instagram.com/',
                }
        },
        {
            name : 'Chương trình khởi nghiệp và phát triển kinh doanh',
            url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOhQ-CLEdgSYgk-SyQr1dWyWbri4edKSDV0Q&s',
            status : "Closing soon",
            price : 11220,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    facebook : 'https://www.facebook.com/',
                    instagram : 'https://www.instagram.com/',
                }
        },
        {
            name : 'Khoa kinh tế',
            url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR11IMZcEWk57OqZE5v-5dMG1FxYEOrYXsduA&s',
            status : "Closing soon",
            price : 11220,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :{
                    instagram : 'https://www.instagram.com/',
                }
        },
        {
            name : 'Viện quản trị kinh doanh',
            url : 'https://bsneu.neu.edu.vn/wp-content/uploads/2020/08/logo-vqtkd-copy-1234.jpg',
            status : "Closing soon",
            price : 11220,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    youtube : 'https://www.youtube.com/',
                }
    
        },
        {
            name : 'Khoa khoa học quản lý',
            url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmhKh8pgX00398k9ZhU5lrlIqg9T08Zh2txA&s',
            status : "Opening soon",
            price : 11220,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    facebook : 'https://www.facebook.com/',
                    instagram : 'https://www.instagram.com/',
                }
        },
        {
            name : 'Khoa môi trường,BĐKH & ĐT',
            url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR14iJj1enk-6HfT0tfCVxVCqhvfdEoxAOemw&s',
            status : "Opening soon",
            price : 11220,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    facebook : 'https://www.facebook.com/',
                    youtube : 'https://www.youtube.com/',
                    instagram : 'https://www.instagram.com/',
                }
        },
        {
            name : 'Khoa luật',
            url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOLtw_W-JZfB54IBCnUfrgyoZLeTAkHHESeA&s',
            status : "Opening soon",
            price : 11220,
            website :'https://www.google.com.vn/?hl=vi',
            socialNetworks :
                {
                    facebook : 'https://www.facebook.com/',
                    youtube : 'https://www.youtube.com/',
                }
        },
    ])
    const [categoties, setCategories] = useState([
        {
            name : "Trường công nghệ",
            url : 'https://i.pinimg.com/originals/9d/72/1b/9d721b537d52237db102a6e760689675.png',
        },
        {   
            name : "Trường kinh tế & QLC",
            url :"https://i.pinimg.com/originals/9d/72/1b/9d721b537d52237db102a6e760689675.png"
        },
        {
            name : "Trường kinh doanh",
            url : 'https://i.pinimg.com/originals/9d/72/1b/9d721b537d52237db102a6e760689675.png',
        },
        {
            name : "CT tiên tiến CLC",
            url : 'https://i.pinimg.com/originals/9d/72/1b/9d721b537d52237db102a6e760689675.png',
        },
        {
            name : "CT cử nhân quốc tế",
            url : 'https://i.pinimg.com/originals/9d/72/1b/9d721b537d52237db102a6e760689675.png',
        },
        {
            name : "CT E - Learning",
            url : 'https://i.pinimg.com/originals/9d/72/1b/9d721b537d52237db102a6e760689675.png',
        },
    ])
    const [searchText, setSearchText] = useState ('')
    const filteredInfos = () => infos.filter(eachInfo => eachInfo.name.toLowerCase()
                                    .includes(searchText.toLowerCase()))
    return<View style ={{flex :1, backgroundColor :'white'}} >
        <View>
            <View style = {{
                marginHorizontal : 10, 
                marginVertical : 10,
                flexDirection : 'row',
                alignItems :'center'
            }}>
                <Icon 
                name = 'search'
                size = {17} 
                color={'black'}
                style = {{
                    position : "absolute",
                    top : 12,
                    left : 10
                }}/>
                <TextInput 
                    autoCorrect = {false}
                    onChangeText={(text) => {
                        setSearchText(text)
                    }}
                style = {{
                        backgroundColor : colors.inactive,
                        height : 40,
                        flex : 1,
                        marginEnd :8,
                        borderRadius : 5,
                        opacity : 0.8,
                        paddingStart : 30
                    }}/>
                <Icon name = 'bars' size = {30} color={'black'}/>
            </View>
            <View style = {{
                height : 100,
            }}>
                <View style= {{
                    height :1, 
                    backgroundColor : colors.inactive,
                }}/>
                <FlatList
                    horizontal
                    keyExtractor={item => item.name}
                    data={categoties}
                    renderItem={({ item, index }) => {
                    return (
                        <TouchableOpacity
                            onPress={() => {
                                alert(`press ${item.name}`)
                            }}
                            style={{
                                justifyContent: 'center',
                                alignItems: 'center',
                                paddingHorizontal: 20, // khoảng cách giữa các khối
                            }}>
                            <Image
                                style={{
                                    width: 60,
                                    height: 60,
                                    resizeMode: 'cover',
                                    borderRadius: 30,
                                    marginBottom: 5
                                }}
                                source={{
                                    uri: item.url
                                }} />
                            <Text style={{
                                color: 'black',
                                fontSize: fontSizes.h6,
                                textAlign : 'center'
                            }}>
                                {item.name}
                            </Text>
                        </TouchableOpacity>
                    );
                }}
                ItemSeparatorComponent={() => (
                    <View
                        style={{
                            width: 1, // Độ dày của đường kẻ dọc
                            backgroundColor: colors.inactive,
                            marginVertical: 15, // Tạo khoảng cách trên dưới cho đường kẻ
                        }}/>)}
                style={{ flex: 1 }}/>
                    <View style= {{height :1, backgroundColor : colors.inactive}} ></View>
                    </View>
                    {/*<ScrollView>
                        {infos.map(eachInfo => <Infoitem
                            info = {eachInfo} key = {eachInfo.name}/>)}
                        </ScrollView>*/}
                    </View>
                        {filteredInfos().length>0 ?<FlatList
                            data = {filteredInfos()}
                            renderItem={({item})=> <Infoitem
                                onPress = {()=>{
                                    alert(`You press item's name : ${item.name}`)
                                }}
                                info = {item} key = {item.name}/>}
                            keyExtractor= {eachInfo => eachInfo.name}
                        /> : <View style = {{flex :1, justifyContent:'center', alignItems:'center' }}>
                                <Text  style = {{
                                    color:'black',
                                    fontSize: fontSizes.h3
                                }}>No food found!</Text>
                        </View>}
                </View>
}
export default InfoList