import React, { useState, useEffect } from 'react';
import {
    Text, 
    View,
    Image,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    KeyboardAvoidingView,
    Keyboard,
    ScrollView
} from 'react-native'
import { images, colors, icons, fontSizes } from '../../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
    function _getColorsFromStatus(status)
    { // dấu gạch dưới thể hiện nội tại bên trong , chỉ có trong file này thôi 
        // if(status.toLowerCase().trim() == 'opening now'){
        //     return colors.success
        // }else if (status.toLowerCase().trim() == "closing soon"){
        //     return colors.alert
        // }else if (status.toLowerCase().trim() == "comming soon"){
        //     return colors.warning
        // }
        // return colors.success
        return status.toLowerCase().trim() == "opening now" ? colors.success :
            (status.toLowerCase().trim() == "closing soon" ? colors.alert :
            (status.toLowerCase().trim() == "comming soon" ? colors.warning : colors.success))
    }
    function Infoitem(props){
    let {name, 
        price, 
        socialNetworks,
        status,
        url, 
        website,
    } = props.info // destructuring an object
    const {onPress} = props
    return(<TouchableOpacity
        onPress={onPress}
        style = {{ 
        height : 150,
        padding : 20,
        paddingStart : 10,
        flexDirection : 'row'
    }}>
        <Image
            style={{
             width : 100,
             height : 100,
             resizeMode : 'cover',
             borderRadius : 10,
             marginRight : 15
            }}
            source={{
                uri: url   
            }} />
        <View style ={{
            flex : 1
        }}>
            <Text style = {{
                color : 'black',
                fontSize : fontSizes.h6,
                fontWeight : 'bold',
            }}> {name} </Text>
            <View style = {{
                height : 1,
                backgroundColor : 'black',
            }}/>
            <View style = {{flexDirection : 'row'}}>
                <Text style = {{
                    color : colors.inactive,
                    fontSize : fontSizes.h6,
                }}>Status : </Text>
                <Text style = {{
                    color : _getColorsFromStatus(status),
                    fontSize : fontSizes.h6,
                }}> {status.toUpperCase()} </Text>
            </View>
                <Text style = {{
                    color : colors.inactive,
                    fontSize : fontSizes.h6,
                }}> Time : 5/9/2024 </Text>
                <Text style = {{
                    color : colors.inactive,
                    fontSize : fontSizes.h6,
                }}>Price : {price} $ </Text>
                  <Text style = {{
                    color : colors.inactive,
                    fontSize : fontSizes.h6,
                }}>Website : {website} </Text> 
                <View style = {{
                    flexDirection : 'row',

                }}>
                    {socialNetworks['facebook'] != undefined  && <Icon
                        style = {{paddingEnd : 5}}
                        name = 'facebook'
                        size = {18}
                        color = {colors.inactive}/>}
                    {socialNetworks['youtube'] != undefined && <Icon 
                        style = {{paddingEnd: 5}}
                        name = 'youtube' 
                        size = {18} 
                        color = {colors.inactive}/>}
                    {socialNetworks['instagram'] != undefined && <Icon
                        name = 'instagram' 
                        size = {18} 
                        color = {colors.inactive}/>}
                </View>

        </View>
    </TouchableOpacity>)
}
export default Infoitem