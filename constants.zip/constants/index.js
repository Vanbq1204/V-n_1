import images from "./images"
import icons from "./icons"
import colors from "./colors"
import fontSizes from "./fontSizes"
export {
    images,
    icons,
    colors,
    fontSizes
}