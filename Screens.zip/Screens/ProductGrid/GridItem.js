import React, { useState, useEffect, startTransition } from 'react';
import {
    Text, 
    View,
    Image,
    TouchableOpacity,
    TextInput,
    FlatList,
    StyleSheet,
    Alert
} from 'react-native'
import { images, colors, icons, fontSizes } from '../../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
import Fivestars from './Fivestars';
function GridItem(props){
        const {item, index,products,setProducts} = props
        return <View style={{
            flex : 0.5,
            height : 350,
            marginLeft : index %2 == 0 ? 10 : 0 ,
            marginTop : 5 ,
            marginRight : 10,
            marginBottom : 10,
            borderRadius : 20,
            borderWidth :1,
            borderColor : colors.inactive,
        }}>
        <View style = {{
            flexDirection : 'row',
            marginTop : 10,
        }} >
            < Image
            style = {
                {
                    width: 90,
                    height: 90,
                    resizeMode: 'cover',
                    borderRadius: 10,
                    marginRight: 15,
                    borderRadius : 20,
                    marginLeft : 5
                }
            }
            source = {
                {
                    uri: item.url 
                }}/>
            <Text style = {
                {
                    color:'black',
                    fontSize: fontSizes.h5,
                    flex : 1,
                    textAlign :'end'
                }
            } > {item.time} 
            </Text>
        </View>
        <Text style = {
                {
                    color:colors.primary,
                    fontSize: fontSizes.h5,
                    fontWeight : 'bold',
                    marginHorizontal : 10,
                    marginTop : 5,
                }
            } > {item.productname} 
            </Text>
            {
                item.spectifications.map(spectifications =>
                    <Text 
                    key={spectifications}
                    style ={{
                        color : 'black',
                        fontSize : fontSizes.h6,
                        paddingHorizontal : 5,
                        paddingBottom : 10
                    }} >* {spectifications}</Text>)
            }
             <View style={{ flex: 1 }} />
            <View style = {{
                flexDirection : 'row',
                padding : 10
            }}>
                <TouchableOpacity 
                onPress={() => {
                       let cloneProducts = products.map(eachProduct => {
                            if(item.productname == eachProduct.productname){
                                return {...eachProduct,isSaved : eachProduct.isSaved == false 
                                    || eachProduct.isSaved == undefined ? true : false}
                            }
                            return eachProduct
                       })
                       setProducts(cloneProducts)
                }}
                style ={{flexDirection : 'row'}} >
                <Icon
                    style = {{marginEnd : 5}}    
                    name = 'heart' size ={22} 
                    color = {item.isSaved == undefined || item.isSaved == false ?
                        colors.inactive : 'red'}/>
                    <Text style= {{
                        color:item.isSaved == undefined || item.isSaved == false ?
                                    colors.inactive : 'red',
                        fontSize : fontSizes.h6*0.8,
                        width : 50
                    }}>Saved for later</Text>
                </TouchableOpacity>
                <View style={{
                    flex : 1,
                }}>
                    <Fivestars numberOfStars = {item.star} ></Fivestars>
                    <Text style ={{ 
                        color : colors.success,
                        fontSize : fontSizes.h6*0.8,
                        textAlign : 'right',
                        paddingTop : 5,
                    }} >{item.reviews} reviews</Text>
                </View>
            </View>
        </View>
}
export default GridItem