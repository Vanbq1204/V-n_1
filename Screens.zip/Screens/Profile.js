import React,{useState, useEffect} from 'react';
import {
    Text, 
    View,
    Image,
    ImageBackground,
    StyleSheet,
    TouchableOpacity,
    Alert,
    TextInput,
    KeyboardAvoidingView,
    Keyboard,
    PlatformColor
} from 'react-native'
import {images,colors,icons,fontSizes } from '../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
    user as UserRepositories,
    population
} from '../repositories'
function Profile(props) {
    UserRepositories.getUserDetail()
    return <SafeAreaView style = {{
        flex :1,
        backgroundColor : 'green'
    }}>
        <Text>This is profile</Text>
    </SafeAreaView>
}
export default Profile
