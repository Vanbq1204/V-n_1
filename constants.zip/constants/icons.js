export default{
    logo : require('../assets/Logo-NEU.png'),
    question : require('../assets/question.png')
}