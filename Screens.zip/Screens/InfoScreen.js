import React,{useState, useEffect} from 'react';
import {
    Text, 
    View,
    Image,
    ImageBackground,
    StyleSheet,
    TouchableOpacity,
    Alert,
    TextInput,
    KeyboardAvoidingView,
    Keyboard,
    PlatformColor,
    ScrollView
} from 'react-native'
import {images,colors,icons,fontSizes } from '../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
import {isValidEmail,isValidPassword} from '../utilies/Validations'

function InfoScreen(props) {
    const [infoItems, setInfoItems] = useState([
        {
            name: 'Quy trình tuyển sinh',
            description: 'Tìm hiểu về các bước trong quy trình tuyển sinh.',
        },
        {
            name: 'Quy đổi điểm IELTS',
            description: 'Thông tin về cách quy đổi điểm IELTS sang điểm chuẩn.',
        },
        {
            name: 'Yêu cầu chứng chỉ',
            description: 'Các chứng chỉ cần thiết để tốt nghiệp.',
        },
        {
            name: 'Quy trình nhận bằng tốt nghiệp',
            description: 'Hướng dẫn nhận bằng tốt nghiệp sau khi hoàn thành khóa học.',
        },
        {
            name: 'Chương trình học bổng',
            description: 'Các chương trình học bổng hiện có và cách đăng ký.',
        },
        {
            name: 'Hỗ trợ tài chính',
            description: 'Thông tin về các chương trình hỗ trợ tài chính dành cho sinh viên.',
        },
    ]);

    return (
        <View style={{ backgroundColor: 'white', flex: 1 }}>
            <ImageBackground
                source={images.background}
                resizeMode='cover'
                style={{ flex: 1 }}
            >
                <View style={{ flex: 20 }}>
                    <View style={styles.header}>
                        <Image
                            source={icons.logo}
                            style={styles.logo}
                        />
                        <Text style={styles.title}>
                            Đại học Kinh tế Quốc dân{'\n'}
                            National Economics University
                        </Text>
                        <View style={{ flex: 1 }} />
                        <Icon 
                            name='question-circle'
                            color='black'
                            size={22}
                            style={styles.icon}
                        />
                    </View>
                </View>
                <View style={styles.content}>
                    <ScrollView contentContainerStyle={styles.scrollContainer}>
                        {infoItems.map((item, index) => (
                            <View key={index} style={styles.infoBox}>
                                <Text style={styles.infoTitle}>{item.name}</Text>
                                <Text style={styles.infoDescription}>{item.description}</Text>
                            </View>
                        ))}
                    </ScrollView>
                </View>
            </ImageBackground>
        </View>
    );
}

const styles = StyleSheet.create({
    header: {
        flexDirection: 'row',
        height: 50,
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    logo: {
        marginStart: 15,
        marginEnd: 5,
        width: 50,
        height: 50,
    },
    title: {
        color: 'black',
        fontSize: fontSizes.h5,
    },
    icon: {
        marginEnd: 18,
    },
    content: {
        flex: 80,
        justifyContent: 'center',
        alignItems: 'center',
    },
    scrollContainer: {
        padding: 10,
    },
    infoBox: {
        backgroundColor: '#f2f2f2',
        padding: 20,
        marginBottom: 15,
        borderRadius: 10,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
    },
    infoTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 5,
    },
    infoDescription: {
        fontSize: 14,
        color: '#666',
    },
});

export default InfoScreen;
