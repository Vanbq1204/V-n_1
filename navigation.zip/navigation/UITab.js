/**
 yarn add react-navigation
 yarn add react-native-safe-area-context
 yarn add @react-navigation/bottom-tabs
 yarn add @react-navigation/native
 yarn add @react-navigation/native-stack
 */
import * as React from 'react'
import {Settings,ProductGridView,InfoList, Profile} from '../Screens'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import {fontSizes,colors} from '../constants'
import Icon from 'react-native-vector-icons/dist/FontAwesome';

const Tab = createBottomTabNavigator()
const screenOptions = ({route})=>({
        headerShown : false,
        tabBarActiveTintColor : 'white',
        tabBarInactiveTintColor : colors.inactive,
        tabBarActiveBackgroundColor : colors.primary,
        tabBarInactiveBackgroundColor : colors.primary,
        tabBarIcon : ({focused, color, size}) => {
            let screenName = route.name
            // let iconName = "facebook";
            // if ( screenName == "InfoGridView"){
            //     iconName = "align-center"
            // } else if(screenName == "InfoList"){
            //     iconName = "window-maximize"
            // } else if( screenName == "Settings"){
            //     iconName = "cogs"
            // } VIẾT THEO KIỂU DỄ HIỂU 
            return <Icon 
            name = {screenName == "InfoGridView" ? "align-center":
                (screenName == "InfoList" ? "window-maximize":(
                    screenName == "Settings"?"cogs": 
                    (route.name == "Profile" ? "user" : "")     // ĐƠN GIẢN HÓA LẠI CÁCH TRÊN
                ))} 
            size = {size || 23} 
            color= {focused ? 'white' : color.inactive}
            />

        },
})
function UITab(props){
        return <Tab.Navigator screenOptions={screenOptions} >
            <Tab.Screen 
                name ={"InfoGridView"} 
                component={ProductGridView}
                options={{
                    tabBarLabel : 'Infomation'
                }}
            />
            <Tab.Screen 
                name ={"InfoList"} 
                component={InfoList}
                options={{
                    tabBarLabel : 'Faculty Overview'
                }}
            />
            <Tab.Screen 
                name ={"Settings"} 
                component={Settings}
                options={{
                    tabBarLabel : 'Settings'
                }}
            />
            <Tab.Screen 
                name ={"Profile"} 
                component={Profile}
                options={{
                    tabBarLabel : 'Profile'
                }}
            />
        </Tab.Navigator>
}
export default UITab