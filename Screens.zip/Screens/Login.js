import React,{useState, useEffect} from 'react';
import {
    Text, 
    View,
    Image,
    ImageBackground,
    StyleSheet,
    TouchableOpacity,
    Alert,
    TextInput,
    KeyboardAvoidingView,
    Keyboard,
    PlatformColor
} from 'react-native'
import {images,colors,icons,fontSizes } from '../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
import {isValidEmail,isValidPassword} from '../utilies/Validations'
function Login(props) {
    const [keyboardIsShown, setKeyBoardIsShown] = useState(false)
    //state for validating
    const [errorEmail, setErrorEmail] = useState('')
    const [errorPassword, setErrorPassword] = useState('')
    // state to store email/password
    const[email, setEmail] = useState('')
    const[password, setPassword] = useState('')
    // Result of login 
    const isValidationOK = () => email.length > 0 &&
                                 password.length >0 &&
                                 isValidEmail(email) == true &&
                                 isValidPassword(password) == true
    useEffect(()=>{
        //componentDidMount
        Keyboard.addListener("keyboardDidShow",()=>{
            setKeyBoardIsShown(true)
        })
        Keyboard.addListener("keyboardDidHide",()=>{
            setKeyBoardIsShown(false)
        })
    })
       //navigation
       const {navigation, route} = props
       // function navigate to/back
       const {navigate, goback} = navigation
    return <KeyboardAvoidingView
    behavior={Platform.OS === "ios" ? "padding" : "height"}
    style ={{
        flex : 100,
        backgroundColor : 'white',
    }}>
        <View style ={{
            flex : 30,
            height : 200,
            flexDirection : "row", // từ trái sang phải
            alignItems :'center',
            justifyContent :'space-around'
        }}>
        <Text style ={{
            color : 'black',
            fontSize : fontSizes.h2,
            fontWeight : "bold",
            width : '50%'
        }} >Already have an Account ? </Text>
        <Image
        tintColor={colors.primary}
        source={
            images.computer
        }style = {{
            width : 120,
            height : 120,
            alignSelf :'center'
        }}/>
        </View >
        <View style = {{
            flex : 30,
        }}>
        <View style= {{
            marginHorizontal : 15,
        }}>
            <Text style ={{
                color: colors.primary,
                fontSize : fontSizes.h6
            }}>Email:</Text>
            <TextInput
                onChangeText={(text)=>{
                    /*
                    if(isValidEmail(text) == false){
                        setErrorEmail('Email not in correct format')
                    } else {
                        setErrorEmail('')
                    }
                    */
                    setErrorEmail(isValidEmail(text) == true ?
                                '' :'Email not in correct format')
                    setEmail(text)
            }}
            style ={{
                color : 'black',
              
            }}
                placeholder ='example@gmail.com'
                placeholderTextColor={colors.placeholder} />
            <View style={{height:1,
                 backgroundColor:colors.primary,
                 width:'100%',
                 marginBottom : 15,
                 marginHorizontal:10,
                 alignSelf:'center'
            }}/>
            <Text style ={{
                color : 'red',
                fontSize : fontSizes.h6,
                marginBottom :15,
                }} >{errorEmail}</Text> 
        </View>
        <View style= {{
            marginHorizontal : 15,
        }}>
            <Text style ={{
                color: colors.primary,
                fontSize : fontSizes.h6
            }}>Password:</Text>
            <TextInput
                onChangeText={(text)=>{
                    setErrorPassword(isValidPassword(text) == true ?
                            '' :'Password must be at least 3 characters')
                    setPassword(text)
            }}
            style ={{
                    color : 'black',
                    
                }}
                editable = {true}
                secureTextEntry = {true} 
                placeholder ='Enter your passsword'
                placeholderTextColor={colors.placeholder}/>
            <View style={{height:1,
                 backgroundColor:colors.primary,
                 width:'100%',
                 marginBottom : 15,
                 marginHorizontal:10,
                 alignSelf:'center'
            }}/>
            <Text style ={{
                color : 'red',
                fontSize : fontSizes.h6,
                marginBottom :15,
                }} >{errorPassword}</Text>  
            </View>
        </View>

                {!keyboardIsShown ? (
            <View style={{
                flex: 25
            }}>
                <TouchableOpacity
                    disabled={isValidationOK() == false}
                    onPress={() => {
                        // alert(`Email = ${email},Password = ${password}`);
                        navigate('UITab')
                    }}
                    style={{
                        backgroundColor: isValidationOK() == true ? colors.primary : colors.inactive ,
                        justifyContent: "center",
                        alignItems: "center",
                        width: '50%',
                        alignSelf: 'center',
                        borderRadius: 20,
                        marginTop: 20
                    }}>
                    <Text style={{
                        padding: 7,
                        fontSize: fontSizes.h5,
                        color: 'white'
                    }}>Login</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => {
                        navigate('Register')
                    }}
                    style={{ padding: 5 }}>
                    <Text style={{
                        padding: 7,
                        fontSize: fontSizes.h6,
                        color: colors.primary,
                        alignSelf: 'center',
                    }}>New user? Register now</Text>
                </TouchableOpacity>
            </View>
        ) : (
            <View style={{
                flex: 25
            }} />
        )}
        {!keyboardIsShown ? (<View style = {{
            flex : 30,
        }}>
            <View style ={{
                height : 30,
                flexDirection :'row',
                alignItems:'center',
                marginHorizontal : 20
            }}>
            <View style ={{height :1, backgroundColor:'black',flex:1}}/>
            <Text style ={{
                padding :8,
                fontSize : fontSizes.h6,
                color: 'black',
                alignSelf :'center',
                marginHorizontal : 5,
            }}>User other method?</Text>
        
             <View style ={{height :1, backgroundColor:'black', flex :1}}/>
            </View>
            <View style={{
                flexDirection: 'row',
                justifyContent:'center',
            }}>
                <Icon name = 'facebook' size = {35} color={colors.facebook}/>
                <View style={{width:15}}/>
                <Icon name = 'google' size = {35} color={colors.google}/>
            </View>
        </View>
     ) : (
        <View style={{
            flex: 25
        }} />
    )}
    </KeyboardAvoidingView>
}
export default Login