import React,{useState, useEffect} from 'react';
import {
    Text, 
    View,
    Image,
    ImageBackground,
    StyleSheet,
    TouchableOpacity,
    Alert
} from 'react-native'
//component = function
// viết dưới dạng create a variable which reference to a function
import {sum2Number,substract2Number,PI} from '../utilies/Calculation'
import {images,icons,colors, Icons,fontSizes} from '../constants'
import { posix } from 'rimraf';
import {UIButton} from '../components/index'
import Icon from 'react-native-vector-icons/dist/FontAwesome';
function Welcome(props) {
    // state => khi state thay đổi thì UI được load lại từ đầu 
    //sẽ biến thành getter và setter
    const [accountTypes, setAccountTypes] = useState([
        {
            name : 'Student',
            isSelected : true,
        },
        {
            name : 'Teacher',
            isSelected : false,
        },
        {
            name : 'Individual',
            isSelected : false,
        },
    ])
    //navigation
    const {navigation, route} = props
    // function navigate to/back
    const {navigate, goback} = navigation
    return <View style ={{
        backgroundColor : 'white',
        flex : 100
    }}>
        <ImageBackground
            source={
                images.background
            }
            resizeMode='cover'
            style ={{
                flex :100,
            }}
        >
        <View style={{
            flex: 20,
        }}>
            <View style={{
                flexDirection :'row',
                height : 50,
                justifyContent :'flex-start',
                alignItems :'center',
            }}>
            <Image
            source={
                icons.logo
            }
            style={{
                    marginStart : 15,
                    marginEnd :5,
                    width: 50,
                    height: 50,
                }}
            />
            <Text style={{
            color:'black',
            fontSize: fontSizes.h5
            }}>Đại học Kinh tế Quốc dân{'\n'}
              National Economics University</Text>
            <View style = {{flex:1}}/>
            <Icon name ={'question-circle'}
                color ={'black'}
                size ={22}
                style ={{
                    marginEnd : 18
                }}
            />
             {/* <Image
            source={icons.question}
            style={{
                    width: 25,
                    height: 25,
                    color:'white',
                    marginEnd : 10
                }}
            /> */}
            </View>
        </View>
        <View style ={{
            flex:20,
            justifyContent: 'center',
            alignItems : 'center',
        
        }}>
            <Text style ={{
                marginBottom: 7, 
                color:"black"
                }}>Welcome to
                </Text>
            <Text style ={{
                marginBottom: 7, 
                color:"black",
                fontWeight :'bold',
                fontSize : 20
            }}
                > Đại học Kinh tế Quốc dân
                </Text>
            <Text style ={{
                marginBottom: 7, 
                color:"black"}}
                >Please select your account type !
                </Text>
            </View>  
        <View style ={{
            flex:40,
        }}>
            {accountTypes.map(accountType =>
            <UIButton 
            key = {accountType.name}
            onPress ={()=>{
                let newAccountTypes = accountTypes.map(eachAccountType =>{
                    return {
                        ...eachAccountType,
                         isSelected :eachAccountType.name== accountType.name
                        }
                })
                setAccountTypes(newAccountTypes);
           }}
           title ={accountType.name}
           isSelected = {accountType.isSelected}
           />)}
        </View>

        <View style ={{
            flex:20,

        }}>
            <UIButton
            onPress = {()=>{
                navigate('Login')
            }}
            title = {'Login'.toUpperCase()}/>
            <Text style ={{
                color:"white",
                fontSize : fontSizes.h5,
                alignSelf : 'center'
            }}
                >Do you want to register new account ?</Text>
            <TouchableOpacity
                onPress={()=>{
                    alert('Press register')
                }}
                style = {{
                padding : 5
                }
            }>
            <Text style ={{
                color : colors.primary,
                fontSize : fontSizes.h5,
                alignSelf : 'center',
                textDecorationLine : 'underline',
            }}>Register</Text>
            </TouchableOpacity>
        </View>
    </ImageBackground>
    </View>
}
export default Welcome 

// read object, variable, funtions from other modules
/*const Welcome = (props) =>{
    // destructuring an ogject bổ xẻ một đối tượng x,y
    const {x,y} = props
    // thứ tự const->let->var
    const {person} = props
    // destructuring đối tượng person 
    const{name, age, email} = person
    const {products} = props
    //JSX
    return<View style ={{
        backgroundColor : 'white'
    }} >
        <Text>Value of x = {x},Value of y = {y}</Text>
        <Text>name ={name}, age={age}, email = {email} </Text>
        {products.map(eachProduct =>
                <Text>{eachProduct.productName},{eachProduct.year},</Text>)}
        <Text>sum 2 and 3 = {sum2Number(2,3)}</Text>
        <Text>10 - 8 = {substract2Number(10,8)}</Text>
        <Text>PI= {PI}</Text>
        </View> // sử dụng dấu nháy bên cạnh số 1 
}
*/


