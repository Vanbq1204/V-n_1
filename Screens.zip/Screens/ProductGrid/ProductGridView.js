import React, { useState, useEffect, startTransition } from 'react';
import {
    Text, 
    View,
    Image,
    TouchableOpacity,
    TextInput,
    FlatList,
    StyleSheet,
    Alert
} from 'react-native'
import { images, colors, icons, fontSizes } from '../../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
import Fivestars from './Fivestars';
import GridItem from './GridItem';
function ProductGridView(props){
    const [products, setProducts] = useState([
        {
            url : 'https://inkythuatso.com/uploads/images/2021/11/logo-neu-inkythuatso-01-09-09-40-17.jpg',
            time : '1/12/2023',
            productname : 'Đại học chính quy ',
            spectifications : [
                "Lễ khai giảng đại học chính quy khóa 65", 
                "17 thủ khoa đầu vào của Đại học Kinh tế Quốc dân",
                "Thông tin tuyển sinh Đại học hệ Chính quy năm 2023",
                "..."
            ],
            reviews : 1200,
            star : 3, 
        },
        {
            url : 'https://inkythuatso.com/uploads/images/2021/11/logo-neu-inkythuatso-01-09-09-40-17.jpg',
            time : '1/1/2024',
            productname : 'Chương trình sau đại học ',
            spectifications : [
                "Thạc sĩ điều hành cao cấp", 
                "Chương trình nghiên cứu sau tiến sĩ",
                "Chương trình đào tạo tiến sĩ giữa Neu và Đại học Lincoln ",
                "..."
            ],
            reviews : 19,
            star : 5, 
        },

        {
            url : 'https://inkythuatso.com/uploads/images/2021/11/logo-neu-inkythuatso-01-09-09-40-17.jpg',
            time : '8/4/2023',
            productname : 'Chương trình cử nhân quốc tế',
            spectifications : [
                "Thông báo Tuyển sinh Chương trình Cử nhân Quốc tế IBD@NEU khóa 20", 
                "Chương trình liên kết đào tự Cử nhân Kinh doanh",
                "Chương trình cử nhân Kinh tế học và tài chính",
                "..."
            ],
            reviews : 589,
            star : 4, 
        },
        {
            url : 'https://inkythuatso.com/uploads/images/2021/11/logo-neu-inkythuatso-01-09-09-40-17.jpg',
            time : '12/8/2024',
            productname : 'Vừa học - Vừa làm',
            spectifications : [
                "Đại học tại chức", 
                "Liên thông ĐHTC",
                "Văn bằng 2 TC"
            ],
            reviews : 25,
            star : 3, 
        },
        {
            url : 'https://inkythuatso.com/uploads/images/2021/11/logo-neu-inkythuatso-01-09-09-40-17.jpg',
            time : '11/7/2024',
            productname : 'Chứng chỉ ngắn hạn ',
            spectifications : [
                "Chứng chỉ Ứng dụng CNTT cơ bản", 
                "Chứng chỉ ngoại ngữ",
                "Chứng chỉ kế toán - kiểm toán",
                "Quản trị kinh doanh",
                "Nghiệp vụ thuế",
                "..."
            ],
            reviews : 25,
            star : 4, 
        },
        {
            url : 'https://inkythuatso.com/uploads/images/2021/11/logo-neu-inkythuatso-01-09-09-40-17.jpg',
            time : '12/1/2024',
            productname : 'Hệ từ xa ',
            spectifications : [
                "Quản trị kinh doanh", 
                "Kế toán",
                "Luật kinh tế",
                "Tài chính ngân hàng",
            ],
            reviews : 100,
            star : 3, 
        }
    ]);
    return <View style = {{
        flex : 1,
        backgroundColor :'white',
    }}>
        <FlatList
            style = {{ marginTop : 5}}
            data = {products}
            numColumns={2}
            keyExtractor={item =>item.productname}
            renderItem={({item,index})=> <GridItem 
            item ={item} 
            index = {index} 
            products={products} 
            setProducts={setProducts} />}
        />
    </View>
}
export default ProductGridView;
