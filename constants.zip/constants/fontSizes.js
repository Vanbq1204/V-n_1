export default {
    h1 : 22,
    h2 : 20,
    h3 : 18,
    h5 : 14,
    h6 : 12
}