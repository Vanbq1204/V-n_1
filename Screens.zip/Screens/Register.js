import React, { useState, useEffect } from 'react';
import {
    Text, 
    View,
    Image,
    StyleSheet,
    TouchableOpacity,
    TextInput,
    KeyboardAvoidingView,
    Keyboard,
    ScrollView
} from 'react-native'
import { images, colors, icons, fontSizes } from '../constants';
import Icon from 'react-native-vector-icons/dist/FontAwesome';
import { isValidEmail, isValidPassword } from '../utilies/Validations';

function Register(props) {
    const [keyboardIsShown, setKeyBoardIsShown] = useState(false);
    const [errorEmail, setErrorEmail] = useState('');
    const [errorPassword, setErrorPassword] = useState('');
    const [errorRePassword, setErrorRePassword] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [rePassword, setRePassword] = useState('');

    const isValidationOK = () => 
        email.length > 0 &&
        password.length > 0 &&
        rePassword.length > 0 &&
        isValidEmail(email) &&
        isValidPassword(password) &&
        password === rePassword;

    useEffect(() => {
        Keyboard.addListener("keyboardDidShow", () => {
            setKeyBoardIsShown(true);
        });
        Keyboard.addListener("keyboardDidHide", () => {
            setKeyBoardIsShown(false);
        });

        return () => {
            Keyboard.removeAllListeners("keyboardDidShow");
            Keyboard.removeAllListeners("keyboardDidHide");
        };
    }, []);
            //navigation
    const {navigation, route} = props
    // function navigate to/back
    const {navigate, goback} = navigation
    return (
        <ScrollView
            style={{
                flex: 100,
                backgroundColor: colors.primary,
            }}>
            <View style={{
                flex: 25,
                height: 200,
                flexDirection: "row",
                alignItems: 'center',
                justifyContent: 'space-around'
            }}>
                <Text style={{
                    color: 'white',
                    fontSize: fontSizes.h2,
                    fontWeight: "bold",
                    width: '50%'
                }}>Already have an Account?</Text>
                <Image
                    tintColor={'white'}
                    source={images.computer}
                    style={{
                        width: 120,
                        height: 120,
                        alignSelf: 'center'
                    }}/>
            </View>

            <View style={{
                flex: 45,
                backgroundColor: 'white',
                padding: 10,
                margin: 10,
                borderRadius: 30,
            }}>
                <View style={{ marginHorizontal: 15 }}>
                    <Text style={{
                        color: colors.primary,
                        fontSize: fontSizes.h6
                    }}>Email:</Text>
                    <TextInput
                        onChangeText={(text) => {
                            setErrorEmail(isValidEmail(text) ? '' : 'Email not in correct format');
                            setEmail(text);
                        }}
                        style={{ color: 'black' }}
                        placeholder='example@gmail.com'
                        placeholderTextColor={colors.placeholder} />
                    <View style={{ height: 1, backgroundColor: colors.primary, width: '100%', marginBottom: 15, alignSelf: 'center' }}/>
                    <Text style={{ color: 'red', fontSize: fontSizes.h6, marginBottom: 10 }}>{errorEmail}</Text>
                </View>

                <View style={{ marginHorizontal: 15 }}>
                    <Text style={{ color: colors.primary, fontSize: fontSizes.h6 }}>Password:</Text>
                    <TextInput
                        onChangeText={(text) => {
                            setErrorPassword(isValidPassword(text) ? '' : 'Password must be at least 3 characters');
                            setPassword(text);
                        }}
                        style={{ color: 'black' }}
                        secureTextEntry={true}
                        placeholder='Enter your password'
                        placeholderTextColor={colors.placeholder} />
                    <View style={{ height: 1, backgroundColor: colors.primary, width: '100%', marginBottom: 10, alignSelf: 'center' }}/>
                    <Text style={{ color: 'red', fontSize: fontSizes.h6, marginBottom: 15 }}>{errorPassword}</Text>
                </View>

                <View style={{ marginHorizontal: 15 }}>
                    <Text style={{ color: colors.primary, fontSize: fontSizes.h6 }}>Retype password:</Text>
                    <TextInput
                        onChangeText={(text) => {
                            setErrorRePassword(text === password ? '' : 'Passwords do not match');
                            setRePassword(text);
                        }}
                        style={{ color: 'black' }}
                        secureTextEntry={true}
                        placeholder='Re-enter your password'
                        placeholderTextColor={colors.placeholder} />
                    <View style={{ height: 1, backgroundColor: colors.primary, width: '100%', marginBottom: 10, alignSelf: 'center' }}/>
                    <Text style={{ color: 'red', fontSize: fontSizes.h6, marginBottom: 5 }}>{errorRePassword}</Text>
                </View>

                <TouchableOpacity
                    disabled={!isValidationOK()}
                    onPress={() => {
                        navigate('UITab')
                    }}
                    style={{
                        backgroundColor: isValidationOK() ? colors.primary : colors.inactive,
                        justifyContent: "center",
                        alignItems: "center",
                        width: '50%',
                        alignSelf: 'center',
                        borderRadius: 20,
                        marginTop: 20
                    }}>
                    <Text style={{ padding: 7, fontSize: fontSizes.h5, color: 'white' }}>Register</Text>
                </TouchableOpacity>
            </View>

            {!keyboardIsShown ? (
                <View style={{ flex: 30 }}>
                    <View style={{ height: 30, flexDirection: 'row', alignItems: 'center', marginHorizontal: 20 }}>
                        <View style={{ height: 1, backgroundColor: 'white', flex: 1 }}/>
                        <Text style={{ padding: 8, fontSize: fontSizes.h6, color: 'white', marginHorizontal: 5 }}>Use other methods?</Text>
                        <View style={{ height: 1, backgroundColor: 'white', flex: 1 }}/>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                        <Icon name='facebook' size={35} color={colors.facebook}/>
                        <View style={{ width: 15 }}/>
                        <Icon name='google' size={35} color={colors.google}/>
                    </View>
                </View>
            ) : (
                <View style={{ flex: 25 }} />
            )}
        </ScrollView>
    );
}

export default Register;
