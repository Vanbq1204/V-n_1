/**
yarn add axios
*/
import Welcome from "./Welcome"
import Login from "./Login"
import Register from "./Register"
import InfoScreen from "./InfoScreen"
import InfoList from "./InfoList/InfoList"
import ProductGridView from "./ProductGrid/ProductGridView"
import Settings from "./Settings"
import Profile from "./Profile"
export {
    Welcome,
    Login,
    Register,
    InfoScreen,
    InfoList,
    ProductGridView,
    Settings,
    Profile
}