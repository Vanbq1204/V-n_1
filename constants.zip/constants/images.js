export default {
    background : require('../assets/backgroud3.jpg'),
    computer : require('../assets/Login.png'),
}