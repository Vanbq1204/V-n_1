import React,{Component} from 'react'
import {
        TouchableOpacity,
        Text,
        View
} from 'react-native'
import Icon from 'react-native-vector-icons/FontAwesome';
import { colors, fontSizes } from '../constants'
    function UIHeader(props){
        const {title} = props
        return <View style = {{
            height : 55,
            backgroundColor : colors.primary
        }} >
            <Text style = {{
                fontSize : fontSizes.h5,
                alignSelf :'center',
                lineHeight : 45,
                color : 'white',
            }}>Settings</Text>
        </View>
        }
export default UIHeader