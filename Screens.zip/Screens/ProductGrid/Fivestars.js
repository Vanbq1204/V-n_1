import React,{useState, useEffect} from 'react';
import {
    Text, 
    View,
    Image,
    ImageBackground,
    StyleSheet,
    TouchableOpacity,
    Alert
} from 'react-native'

import {images,icons,colors, Icons,fontSizes} from '../../constants'
import Icon from 'react-native-vector-icons/dist/FontAwesome';
function Fivestars (props){
            const {numberOfStars} = props
            return<View style = {{
                flexDirection :'row',
                justifyContent : 'flex-end'
                }} > 
                {[0,1,2,3,4].map(item => <Icon
                key = {item} // thêm thuộc tính key cho mỗi phần tử
                style = {{marginEnd : 2}}    
                name = 'star' size ={10} 
                color = {item<=numberOfStars-1 ? colors.warning : colors.inactive}
                />)}
                </View>
}
export default Fivestars